package clases;

public class Internamiento {
	private int codInter,codPac,numCama;
	private String fechaIng,horaIng,fechaSal,horaSal;
	private double totalPagar;
	private int estado;
	public Internamiento(int codInter, int codPac, int numCama, String fechaIng, String horaIng, String fechaSal,
			String horaSal, double totalPagar, int estado) {
		this.codInter = codInter;
		this.codPac = codPac;
		this.numCama = numCama;
		this.fechaIng = fechaIng;
		this.horaIng = horaIng;
		this.fechaSal = fechaSal;
		this.horaSal = horaSal;
		this.totalPagar = totalPagar;
		this.estado = estado;
	}
	public int getCodInter() {
		return codInter;
	}
	public void setCodInter(int codInter) {
		this.codInter = codInter;
	}
	public int getCodPac() {
		return codPac;
	}
	public void setCodPac(int codPac) {
		this.codPac = codPac;
	}
	public int getNumCama() {
		return numCama;
	}
	public void setNumCama(int numCama) {
		this.numCama = numCama;
	}
	public String getFechaIng() {
		return fechaIng;
	}
	public void setFechaIng(String fechaIng) {
		this.fechaIng = fechaIng;
	}
	public String getHoraIng() {
		return horaIng;
	}
	public void setHoraIng(String horaIng) {
		this.horaIng = horaIng;
	}
	public String getFechaSal() {
		return fechaSal;
	}
	public void setFechaSal(String fechaSal) {
		this.fechaSal = fechaSal;
	}
	public String getHoraSal() {
		return horaSal;
	}
	public void setHoraSal(String horaSal) {
		this.horaSal = horaSal;
	}
	public double getTotalPagar() {
		return totalPagar;
	}
	public void setTotalPagar(double totalPagar) {
		this.totalPagar = totalPagar;
	}
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
}
