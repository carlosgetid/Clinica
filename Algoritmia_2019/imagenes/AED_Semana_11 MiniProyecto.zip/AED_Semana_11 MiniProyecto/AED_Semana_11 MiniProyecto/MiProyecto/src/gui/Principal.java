package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import arreglos.ArregloCamas;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Principal extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JButton btnCamas;
	private JButton btnReportes;
	private JButton btnSalir;

	public static ArregloCamas ac=new ArregloCamas();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnCamas = new JButton("Camas");
		btnCamas.addActionListener(this);
		btnCamas.setBounds(28, 72, 89, 23);
		contentPane.add(btnCamas);
		
		btnReportes = new JButton("Reportes");
		btnReportes.addActionListener(this);
		btnReportes.setBounds(220, 72, 89, 23);
		contentPane.add(btnReportes);
		
		btnSalir = new JButton("Salir");
		btnSalir.addActionListener(this);
		btnSalir.setBounds(117, 125, 89, 23);
		contentPane.add(btnSalir);
	}

	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnSalir) {
			btnSalirActionPerformed(arg0);
		}
		if (arg0.getSource() == btnReportes) {
			btnReportesActionPerformed(arg0);
		}
		if (arg0.getSource() == btnCamas) {
			btnCamasActionPerformed(arg0);
		}
	}
	protected void btnCamasActionPerformed(ActionEvent arg0) {
		CamaGui c=new CamaGui();
		c.setVisible(true);
	}
	protected void btnReportesActionPerformed(ActionEvent arg0) {
		ReportesGui r=new ReportesGui();
		r.setVisible(true);
	}
	protected void btnSalirActionPerformed(ActionEvent arg0) {
		System.exit(0);
	}
}
