package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.metal.MetalPopupMenuSeparatorUI;

import arreglos.ArregloCamas;
import clases.Cama;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.rmi.activation.ActivationMonitor;
import java.awt.event.ItemEvent;

public class CamaGui extends JFrame implements ActionListener, ItemListener {

	private JPanel contentPane;
	private JLabel lblCodigo;
	private JLabel lblCategoria;
	private JLabel lblPrecioDia;
	private JLabel lblEstado;
	private JTextField txtNumero;
	private JComboBox cboCategoria;
	private JTextField txtPrecio;
	private JComboBox cboEstado;
	private JScrollPane scrollPane;
	private JTextArea txtS;
	private JButton btnAdicionar;
	private JButton btnEliminar;
	private JButton btnModificar;
	private JButton btnConsultar;
	private JButton btnCerrar;
	private JButton btnEliminarOcupadas;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CamaGui frame = new CamaGui();
					frame.setVisible(true);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CamaGui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 407);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblCodigo = new JLabel("Numero Cama");
		lblCodigo.setBounds(20, 33, 87, 14);
		contentPane.add(lblCodigo);
		
		lblCategoria = new JLabel("Categoria");
		lblCategoria.setBounds(20, 68, 73, 14);
		contentPane.add(lblCategoria);
		
		lblPrecioDia = new JLabel("Precio dia:");
		lblPrecioDia.setBounds(20, 106, 73, 14);
		contentPane.add(lblPrecioDia);
		
		lblEstado = new JLabel("Estado:");
		lblEstado.setBounds(20, 140, 73, 14);
		contentPane.add(lblEstado);
		
		txtNumero = new JTextField();
		txtNumero.setBounds(109, 30, 86, 20);
		contentPane.add(txtNumero);
		txtNumero.setColumns(10);
		
		cboCategoria = new JComboBox();
		cboCategoria.addItemListener(this);
		cboCategoria.setModel(new DefaultComboBoxModel(new String[] {"Basica", "Estandard", "Premium"}));
		cboCategoria.setBounds(103, 65, 92, 20);
		contentPane.add(cboCategoria);
		
		txtPrecio = new JTextField();
		txtPrecio.setEditable(false);
		txtPrecio.setBounds(109, 103, 86, 20);
		contentPane.add(txtPrecio);
		txtPrecio.setColumns(10);
		
		cboEstado = new JComboBox();
		cboEstado.setModel(new DefaultComboBoxModel(new String[] {"Libre", "Ocupado"}));
		cboEstado.setBounds(103, 137, 92, 20);
		contentPane.add(cboEstado);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 216, 334, 141);
		contentPane.add(scrollPane);
		
		txtS = new JTextArea();
		scrollPane.setViewportView(txtS);
		
		btnAdicionar = new JButton("Adicionar");
		btnAdicionar.addActionListener(this);
		btnAdicionar.setBounds(265, 24, 89, 23);
		contentPane.add(btnAdicionar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(this);
		btnEliminar.setBounds(265, 50, 89, 23);
		contentPane.add(btnEliminar);
		
		btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(this);
		btnModificar.setBounds(265, 79, 89, 23);
		contentPane.add(btnModificar);
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.addActionListener(this);
		btnConsultar.setBounds(265, 112, 89, 23);
		contentPane.add(btnConsultar);
		
		btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(this);
		btnCerrar.setBounds(265, 147, 89, 23);
		contentPane.add(btnCerrar);
		
		btnEliminarOcupadas = new JButton("Eliminar Ocupadas");
		btnEliminarOcupadas.addActionListener(this);
		btnEliminarOcupadas.setBounds(265, 181, 119, 23);
		contentPane.add(btnEliminarOcupadas);
		listar();
		codigocorrelativo();
	}
	private void codigocorrelativo(){
		txtNumero.setText(""+Principal.ac.codigoCorrelativo());
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnEliminarOcupadas) {
			btnEliminarOcupadasActionPerformed(arg0);
		}
		if (arg0.getSource() == btnConsultar) {
			btnConsultarActionPerformed(arg0);
		}
		if (arg0.getSource() == btnModificar) {
			btnModificarActionPerformed(arg0);
		}
		if (arg0.getSource() == btnCerrar) {
			btnCerrarActionPerformed(arg0);
		}
		if (arg0.getSource() == btnEliminar) {
			actionPerformedBtnEliminar(arg0);
		}
		if (arg0.getSource() == btnAdicionar) {
			actionPerformedBtnAdicionar(arg0);
		}
	}
	//ArregloCamas ac=new ArregloCamas();
	int leerNumero(){
		return Integer.parseInt(txtNumero.getText());
	}
	int leerEstado(){
		return cboEstado.getSelectedIndex();
	}
	double leerPrecio(){
		return Double.parseDouble(txtPrecio.getText());
	}
	int leerCat(){
		return cboCategoria.getSelectedIndex();
	}
	protected void actionPerformedBtnAdicionar(ActionEvent arg0) {
		if(Principal.ac.buscar(leerNumero())==null){
			Cama c=new Cama(leerNumero(), leerCat(), leerPrecio(),leerEstado());
			Principal.ac.adicionar(c);
			JOptionPane.showMessageDialog(this, "datos ingresados correctamente");
			listar();
			Principal.ac.grabarCama();
			codigocorrelativo();
		}
		else JOptionPane.showMessageDialog(this, "ya existe");
	}
	void listar(){
		txtS.setText("");
		imprimir("Num.\tCategoria\tPrecio\tEstado");
		for(int i=0;i<Principal.ac.tama�o();i++){
			Cama c=Principal.ac.obtener(i);
			imprimir(
					c.getNumeroCama()+"\t"
					+c.getCategoria()+"\t"
					+c.getPrecioDia()+"\t"
					+c.getEstado()
					);
		}			
	}
	void imprimir(String x){
		txtS.append(x+"\n");
	}
	public void itemStateChanged(ItemEvent arg0) {
		if (arg0.getSource() == cboCategoria) {
			itemStateChangedCboCategoria(arg0);
		}
	}
	protected void itemStateChangedCboCategoria(ItemEvent arg0) {
		int op=cboCategoria.getSelectedIndex();
		if(op==0) txtPrecio.setText(""+70);
		else if(op==1)txtPrecio.setText(""+120);
		else				txtPrecio.setText(""+180);
	}
	protected void actionPerformedBtnEliminar(ActionEvent arg0) {
		if(Principal.ac.buscar(leerNumero())!=null){
			Cama c=Principal.ac.buscar(leerNumero());
			Principal.ac.eliminar(c);
			listar();
			Principal.ac.grabarCama();
			codigocorrelativo();
		}else
			JOptionPane.showMessageDialog(this, "Cama no existe");			
	}
	protected void btnCerrarActionPerformed(ActionEvent arg0) {
		dispose();
	}
	protected void btnModificarActionPerformed(ActionEvent arg0) {
		int num = leerNumero();
		Cama c = Principal.ac.buscar(num);
		if (c != null) {
			int cat = leerCat();
			double precio= leerPrecio();
			int estado = leerEstado();
			c.setCategoria(cat);
			c.setPrecioDia(precio);
			c.setEstado(estado);
			listar();
		}
		else
			JOptionPane.showMessageDialog(this,"el C�DIGO no existe");
	}
	protected void btnConsultarActionPerformed(ActionEvent arg0) {
		int num = leerNumero();
		Cama c = Principal.ac.buscar(num);
		if (c != null) {
			cboCategoria.setSelectedIndex(c.getCategoria());
			txtPrecio.setText(""+c.getPrecioDia());
			cboEstado.setSelectedIndex(c.getEstado());
		}
		else
			JOptionPane.showMessageDialog(this,"el C�DIGO no existe");
	}
	protected void btnEliminarOcupadasActionPerformed(ActionEvent arg0) {
		for(int i=Principal.ac.tama�o()-1;i>=0;i--){
			Cama c=Principal.ac.obtener(i);
			if(c.getEstado()==1)
				Principal.ac.eliminar(c);
		}
		listar();
	}
}




