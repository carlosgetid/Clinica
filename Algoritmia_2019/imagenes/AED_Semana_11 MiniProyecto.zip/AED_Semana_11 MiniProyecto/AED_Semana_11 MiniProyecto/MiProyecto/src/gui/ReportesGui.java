package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import clases.Cama;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReportesGui extends JFrame implements ItemListener, ActionListener {

	private JPanel contentPane;
	private JComboBox cboReportes;
	private JTextArea txtS;
	private JScrollPane scrollPane;
	private JButton btnCerrar;
	private JLabel lblReportes;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReportesGui frame = new ReportesGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReportesGui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblReportes = new JLabel("Reportes:");
		lblReportes.setBounds(10, 24, 46, 14);
		contentPane.add(lblReportes);
		
		cboReportes = new JComboBox();
		cboReportes.addItemListener(this);
		cboReportes.setModel(new DefaultComboBoxModel(new String[] {"seleccione una opcion", "Total Camas", "Camas Libres", "Camas Ocupadas"}));
		cboReportes.setBounds(119, 21, 159, 20);
		contentPane.add(cboReportes);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 64, 360, 186);
		contentPane.add(scrollPane);
		
		txtS = new JTextArea();
		scrollPane.setViewportView(txtS);
		
		btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(this);
		btnCerrar.setBounds(323, 20, 89, 23);
		contentPane.add(btnCerrar);
	}
	public void itemStateChanged(ItemEvent e) {
		if (e.getSource() == cboReportes) {
			comboBoxItemStateChanged(e);
		}
	}
	protected void comboBoxItemStateChanged(ItemEvent e) {
		int op=cboReportes.getSelectedIndex();
		if(op==0) mensaje("seleccione un reporte");
		else if(op==1) camasTodos();
		else if(op==2) camasLibres();
		else 		   camasOcupadas();
	}
	void camasTodos(){	
		txtS.setText("");
		imprimir("Num.\tCategoria\tPrecio\tEstado");
		for(int i=0;i<Principal.ac.tama�o();i++){
			Cama c=Principal.ac.obtener(i);
			imprimir(
					c.getNumeroCama()+"\t"
					+c.getCategoria()+"\t"
					+c.getPrecioDia()+"\t"
					+c.getEstado()
					);
		}	
	}
	void camasLibres(){
		txtS.setText("");
		imprimir("Num.\tCategoria\tPrecio\tEstado");
		for(int i=0;i<Principal.ac.tama�o();i++){
			Cama c=Principal.ac.obtener(i);
			if(c.getEstado()==0)
			imprimir(
					c.getNumeroCama()+"\t"
					+c.getCategoria()+"\t"
					+c.getPrecioDia()+"\t"
					+c.getEstado()
					);
		}	
	}
	void camasOcupadas(){
		txtS.setText("");
		imprimir("Num.\tCategoria\tPrecio\tEstado");
		for(int i=0;i<Principal.ac.tama�o();i++){
			Cama c=Principal.ac.obtener(i);
			if(c.getEstado()==1)
			imprimir(
					c.getNumeroCama()+"\t"
					+c.getCategoria()+"\t"
					+c.getPrecioDia()+"\t"
					+c.getEstado()
					);
		}	
	}
	void imprimir(String x){
		txtS.append(x+"\n");
	}
	void mensaje(String msj){
		JOptionPane.showMessageDialog(this, msj);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == btnCerrar) {
			btnCerrarActionPerformed(arg0);
		}
	}
	protected void btnCerrarActionPerformed(ActionEvent arg0) {
		dispose();
	}
}
