package arreglos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import clases.Cama;

public class ArregloCamas {
	private ArrayList<Cama>acam;

	public ArregloCamas() {
		acam=new ArrayList<Cama>();
		cargarCamas();
	}
	public void adicionar(Cama x){
		acam.add(x);
	}
	public Cama obtener(int pos){
		return acam.get(pos);
	}
	public int tama�o(){
		return acam.size();
	}
	public Cama buscar(int num){
		for(Cama c:acam)
			if(c.getNumeroCama()==num)
				return c;
		return null;
	}
	public void eliminar(Cama c){
		acam.remove(c);
	}
	public int codigoCorrelativo(){
		if(tama�o()==0) return 1;
		else
			return obtener(tama�o()-1).getNumeroCama()+1;
	}
	private void cargarCamas() {
		try {
			BufferedReader br;
			String linea;
			int num,cat,estado;
			double precio;
			String[] s;
			br = new BufferedReader(new FileReader("camas.txt"));
			while ((linea = br.readLine()) != null) {
				s = linea.split(";");
				num = Integer.parseInt(s[0].trim());
				cat = Integer.parseInt(s[1].trim());
				precio = Double.parseDouble(s[2].trim());
				estado = Integer.parseInt(s[3].trim());
				adicionar(new Cama(num, cat, precio, estado));
			}
			br.close();
		}
		catch (Exception e) {
		}
	}
	public void grabarCama(){
		try {
			PrintWriter pw;
			String linea;
			pw = new PrintWriter(new FileWriter("camas.txt"));
			for (Cama c:acam){
				linea = c.getNumeroCama() + ";" +
					    c.getCategoria() + ";" +
						c.getPrecioDia() + ";" +
						c.getEstado();
				pw.println(linea);
			}
			pw.close();			
		} catch (Exception e) {
		}//fin del catch
	}	//fin del metodo
}//fin de la clase
